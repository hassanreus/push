# Random tests for `fillit`

### Usage

`git clone https://github.com/jzck/fillit-tests.git`  
`cd fillit-tests`  
`./test /path/to/fillit size`

to test with "size" randomly picked tetriminos, change size to whatever.
